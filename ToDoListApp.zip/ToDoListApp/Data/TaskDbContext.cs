﻿using Microsoft.EntityFrameworkCore;
using ToDoListApp.Models;

public class TaskDbContext : DbContext
{
    public TaskDbContext(DbContextOptions<TaskDbContext> options)
        : base(options)
    {
    }

    public DbSet<TodoTask> Tasks { get; set; }
}
