﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ToDoListApp.Models
{
    public class MyTask
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Please enter a task title.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Please enter a task description.")]
        public string Description { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Due Date")]
        public DateTime DueDate { get; set; }

        [Display(Name = "Completed")]
        public bool IsComplete { get; set; }
    }
}
